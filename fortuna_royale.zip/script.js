function registrar() {
    alert("Redirecionando para a página de cadastro...");
    window.location.href = "cadastro.html";
}
